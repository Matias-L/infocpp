#include <iostream>
using namespace std;

//    SOLUCIONARIO DE EJERCICIOS
//
//
//    Ejercicio Gu�a 1 N1


int main()
{

// Usando endl

	cout << "a)" << endl << " ______" << endl << "|      |" << endl  << "|      |" << endl << "|______|" << endl << endl;
	
	cout << "b)" << endl << "   /\\" << endl << "  /  \\" << endl << " /    \\" << endl << "/______\\" << endl << endl;

	cout << "c)" << endl << "  ____" << endl << " /    \\" << endl << "/      \\" << endl << "\\      /" << endl << " \\____/" << endl << endl;

// Usando \n

    cout << "a)\n ______\n|      |\n|      |\n|______|\n\n" ;

    cout << "b)\n   /\\   \n  /  \\  \n /    \\ \n/______\\\n\n" ;

    cout << "c)\n  ____  \n /    \\ \n/      \\\n\\      /\n \\____/\n\n";
 
    system("PAUSE");
    
    return 0;
}
