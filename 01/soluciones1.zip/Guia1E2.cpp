#include <iostream>
using namespace std;

//    SOLUCIONARIO DE EJERCICIOS
//
//
//    Ejercicio Gu�a 1 N2

int main()
{
    
	cout << "Resultados\n\n";
    
	cout << "a) " << (5+3)/(3+1) << endl;
     
	cout << "b) " << (6/3)*(6/3) << endl;
      
	cout << "c) " << 3.0/2 << endl;
    
	cout << "d) " << 1e4+1e3+1e2*1.0/2-10 << endl << endl;
 
    system("PAUSE");
    
    return 0;
    
}
